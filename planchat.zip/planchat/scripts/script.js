// تحديد عناصر واجهة المستخدم
const loginContainer = document.getElementById('loginContainer');
const chatApp = document.getElementById('chatApp');
const loginButton = document.getElementById('loginButton');
const profileButton = document.getElementById('profileButton');
const messagesButton = document.getElementById('messagesButton');
const profileModal = document.getElementById('profileModal');
const messagesModal = document.getElementById('messagesModal');
const closeProfileButton = document.getElementById('closeProfileButton');
const closeMessagesButton = document.getElementById('closeMessagesButton');
const messagesList = document.getElementById('messagesList');

// بيانات الرسائل (مثال)
const receivedMessages = [
    { sender: 'Alice', message: 'Hello, how are you?' },
    { sender: 'Bob', message: 'Are you free later?' },
];

// عرض نافذة الرسائل
messagesButton.addEventListener('click', () => {
    messagesList.innerHTML = ''; // تفريغ الرسائل القديمة
    receivedMessages.forEach(msg => {
        const li = document.createElement('li');
        li.textContent = `${msg.sender}: ${msg.message}`;
        messagesList.appendChild(li);
    });
    messagesModal.classList.remove('hidden');
});

// إغلاق نافذة الرسائل
closeMessagesButton.addEventListener('click', () => {
    messagesModal.classList.add('hidden');
});

// عرض نافذة الملف الشخصي
profileButton.addEventListener('click', () => {
    profileModal.classList.remove('hidden');
});

// إغلاق نافذة الملف الشخصي
closeProfileButton.addEventListener('click', () => {
    profileModal.classList.add('hidden');
});

// تسجيل الدخول
loginButton.addEventListener('click', () => {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (username && password) {
        loginContainer.classList.add('hidden');
        chatApp.classList.remove('hidden');
    } else {
        alert('Please enter both username and password.');
    }
});

